﻿/*==========================================================
    Author      : Ranjithprabhu K
    Date Created: 13 Jan 2016
    Description : Controller to handle About page
    Change Log
    s.no      date    author     description     


 ===========================================================*/

dashboard.controller("AboutController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        console.log("coming to About controller");

    }]);

