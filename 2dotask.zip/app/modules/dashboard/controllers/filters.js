dashboard.controller("filters", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        console.log("coming to About controller");

    }]);